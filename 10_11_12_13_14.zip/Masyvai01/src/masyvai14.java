import java.util.Arrays;

public class masyvai14 {

	public static void main(String[] args) {
	
		int[] arr = Masyvu_metodai.getArray(25, -10, 20);
		Masyvu_metodai.printArray(arr);
        int g = 1;
        int z = 20;
        int naujas_g = arr[z];
        int naujas_z = arr[g];
        arr[z] = naujas_z;
        arr[g] = naujas_g;
        
        System.out.println( "Sukeistas masyvas: " + Arrays.toString(arr));
        
	}

}
