import java.util.Arrays;
import java.util.Scanner;

public class masyvai12 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);

		int[] Arrarat = Masyvu_metodai.getArray(30, 0, 20); // n duotas30

		Masyvu_metodai.printArray(Arrarat); // atspausti masyvo reiksmes

		System.out.println(" Įveskite kintamąjį nuo 0 iki 30 į kurio vietą statysim 100: ");

		int zmogus = reader.nextInt();

		int zmoniskumas = 1; // ne programeriams reikia priskirti viena skaičiu.

		Arrarat[zmogus - zmoniskumas] = 100; //pakeisti prigimtį - iš žmogaus atimti žmogiškumą

		System.out.println("Pakeistas kintamasis yra tas, kurį pakeitei :" + Arrays.toString(Arrarat));

		reader.close();
	}

}
