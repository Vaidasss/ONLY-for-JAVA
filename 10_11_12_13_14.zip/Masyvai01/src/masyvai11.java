
public class masyvai11 {

	public static void main(String[] args) {

		int[] Barrka = Masyvu_metodai.getArray(20, 0, 20);// n duotas20, min, max
		Masyvu_metodai.printArray(Barrka);
		int suma = 0;

		for (int i = 0; i < Barrka.length; i++) {
			if (Barrka[i] % 3 == 0) {
				System.out.println(Barrka[i]);
				suma = suma + Barrka[i];
			}
		}
		System.out.println("Suma" + suma);
	}

}
