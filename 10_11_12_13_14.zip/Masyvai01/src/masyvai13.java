import java.util.Arrays;

public class masyvai13 {

	public static void main(String[] args) {
		int[] pirmasMas = Masyvu_metodai.getArray(20, -5, 20);
		int[] antrasMas = new int[20];

		Masyvu_metodai.printArray(pirmasMas);

		for (int i = 0; i < pirmasMas.length; i++) {
			if (pirmasMas[i] > 0) {
				antrasMas[i] = pirmasMas[i];
			}
		}
		System.out.println("Teigiamų skaičių masyvas yra: " + Arrays.toString(antrasMas));

	}

}
// kaip padaryti, kad neliktų 0 vietoje neigiamo?