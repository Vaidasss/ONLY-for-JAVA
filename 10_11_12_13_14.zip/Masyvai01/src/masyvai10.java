

public class masyvai10 {
	
	public static void main(String[] args) {
		
		int[] arrka = Masyvu_metodai.getArray(10, -10, 20) ;
		
		Masyvu_metodai.printArray(arrka); // arr -> a
		
		int kiekNuliu = 0;
		for(int i = 0;i < arrka.length; i++) {
			 if(arrka[i] == 0) {
				 kiekNuliu++;
			 }
		 }
		System.out.println(kiekNuliu);
		
	}
	
}